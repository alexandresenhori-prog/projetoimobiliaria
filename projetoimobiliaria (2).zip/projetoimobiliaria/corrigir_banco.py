import psycopg2

def corrigir_tabelas():
    print("--- INICIANDO CORREÇÃO DO BANCO DE DADOS ---")
    
    try:
        conn = psycopg2.connect(
            host="localhost",
            database="imobiliaria_xandi",
            user="postgres",
            password="280814As@",
            port="5432"12
        )
        cur = conn.cursor()
        
        print("1. Conexão estabelecida.")

        # Lista de colunas que o sistema novo exige
        comandos_sql = [
            "ALTER TABLE clientes ADD COLUMN IF NOT EXISTS sexo VARCHAR(20);",
            "ALTER TABLE clientes ADD COLUMN IF NOT EXISTS data_nascimento DATE;",
            "ALTER TABLE clientes ADD COLUMN IF NOT EXISTS cep VARCHAR(20);",
            "ALTER TABLE clientes ADD COLUMN IF NOT EXISTS endereco_completo TEXT;",
            "ALTER TABLE clientes ADD COLUMN IF NOT EXISTS telefone VARCHAR(30);",
            "ALTER TABLE clientes ADD COLUMN IF NOT EXISTS email VARCHAR(100);",
            "ALTER TABLE clientes ADD COLUMN IF NOT EXISTS tipo_pessoa VARCHAR(5);",
            # Garante que documento é UNIQUE para não duplicar
            "ALTER TABLE clientes DROP CONSTRAINT IF EXISTS clientes_documento_key;",
            "ALTER TABLE clientes ADD CONSTRAINT clientes_documento_key UNIQUE (documento);"
        ]

        for comando in comandos_sql:
            try:
                cur.execute(comando)
                conn.commit()
            except Exception as e:
                conn.rollback()
                print(f"   Aviso (pode ignorar): {e}")

        print("2. Colunas 'sexo', 'endereço', etc. verificadas/criadas com sucesso.")
        print("--- CONCLUÍDO! AGORA SEU BANCO ESTÁ ATUALIZADO ---")
        
        cur.close()
        conn.close()
        
    except Exception as e:
        print(f"ERRO FATAL: {e}")
        print("Verifique se a senha do banco está correta no código.")

if __name__ == "__main__":
    corrigir_tabelas()
    input("\nPressione ENTER para sair...")